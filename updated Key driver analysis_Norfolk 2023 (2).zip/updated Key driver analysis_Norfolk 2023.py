#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pandas as pd
import statsmodels.api as sm
# Read the CSV file
df = pd.read_csv('Norfolk2023_raw data.csv')

# Define Likert scale mapping
likert_mapping = {
    'Strongly agree': 100,
    'Agree': 75,
    'Neither agree nor disagree': 50,
    'Disagree': 25,
    'Strongly disagree': 0
}

# Define question labels
question_labels = {
    'Q1': 'I am confident that I can perform effectively across a range of different tasks',
    'Q2': 'I often go the extra miles to get my job done',
    'Q3': 'I feel a sense of pride about my job',
    'Q4': 'I often experience excessive pressure in my role',
    'Q5': 'I feel my pay and benefits are reasonable in comparison with other similar roles in NCC',
    'Q6': 'I actively take opportunities to exchange views about my work issues with others in my team',
    'Q7': 'My commitment to public service motivates me to do as well as I can in my job',
    'Q8': 'I take responsibility for my personal development',
    'Q9': 'I believe I can make a difference by giving you my views',
    'Q10': 'My role makes a positive difference to the lives of people in Norfolk',
    'Q11': 'My work goals are related to future plans of my service',
    'Q12': 'I can see a life-friendly career with NCC',
    'Q13': 'There is a clear link between my Performance Development Discussion and my teams goals',
    'Q14': 'There is a willingness in my team to find better ways of working',
    'Q15': 'My manager recognises that speaking openly about work related issues provides an opportunity to improve things',
    'Q16': 'I am satisfied with the way my manager conducts my Performance Development Discussion',
    'Q17': 'I have useful conversations with my manager to find practical solutions to problems I experience at work',
    'Q18': 'My manager encourages conversations that enable the team to be more effective in achieving its performance goals',
    'Q19': 'I trust my manager to treat me fairly',
    'Q20': 'I am willing to put myself out for my team members when required',
    'Q21': 'The way my manager manages contributes positively to my health and wellbeing',
    'Q22': 'Hybrid working is working well for me and my customers',
    'Q23': 'My manager encourages me and my colleagues to be flexible about when and where we work and to use space and technology creatively',
    'Q24': 'I have access to the right resources to support hybrid working',
    'Q25': 'My employer invests in building my capabilities through all forms of learning and development',
    'Q26': 'My employer values my achievements at work',
    'Q27': 'My employer demonstrates a genuine concern for my health, safety and well-being',
    'Q28': 'I feel a strong sense of loyalty to NCC',
    'Q29': 'I would recommend working for NCC to a friend',
    'Q30': 'NCCs Directors and Heads of Service inspire me to use my own initiative',
    'Q31': 'NCCs Leader and Executive Directors have a clear vision for the future of the organisation',
    'Q32': 'I trust NCC to treat me fairly',
    'Q33': 'NCC recognises that speaking openly about workplace challenges provides an opportunity to improve things',
    'Q34': 'Overall, I am satisfied with the employment deal (what I receive and what I am expected to give in return) provided by NCC',
    'Q35': 'My employer takes appropriate action to prevent and deal with risks of violence, bullying and harassment in any aspect of my work',
    'Q36': 'I understand NCCs values and principles',
    'Q37': 'I am involved in deciding on changes introduced that affect my service',
    'Q38': 'I am able to make suggestions to improve the work of my service',
    'Q39': 'When changes take place at NCC, the reasons are communicated effectively',
    'Q40': 'Compliance with internal procedures often makes it difficult to be creative',
    'Q41': 'My personal development preferences are often overridden by the needs of the organisation',
    'Q42': 'I am often required to do more with less resources',
    'Q43': 'Although NCC advocates cross-organisation working and collaboration, competing priorities often mean its difficult to do',
    'Q44': 'Conversational - e.g. Respectful, Good listener',
    'Q45': 'Innovative - e.g. Imaginative, Inspiring',
    'Q46': 'Capable - e.g. Competent, Confident',
    'Q47': 'Trustworthy - e.g. Honest, Reliable',
    'Q48': 'Supportive - e.g. Compassionate, Appreciative',
    'Q49': 'Directive - e.g. Authoritarian, Controlling',
    'Q50': 'Developmental - e.g. Coaches, Stimulates thinking, learning and growth'

}


# Iterate over columns
for col in df.columns:
    # Check if all values in the column are in the Likert mapping
    if all(value in likert_mapping.keys() for value in df[col].unique()):
        # Map Likert values to numeric values
        df[col] = df[col].map(likert_mapping)

# Calculate mean values for Likert scale columns
likert_columns = [col for col in df.columns if set(df[col]) == set(likert_mapping.values())]
mean_values={}
for col in likert_columns:
    mean_value = df[col].mean()
    mean_values[question_labels.get(col, col)]= mean_value
    
# Create DataFrame for mean values
mean_df = pd.DataFrame(list(mean_values.values()), index=question_labels.values(), columns=['Mean Value'])
# Reset index to move the questions as a column
mean_df.reset_index(inplace=True)

# Rename the columns
mean_df.columns = ['Question', 'Mean Value']

#print(mean_df)
# Define an empty list to hold dictionaries of data
mean_data = []

# Define questions for each variable
variables = {
    'PC': ['Q5', 'Q13', 'Q19', 'Q32'],
    'POS': ['Q25', 'Q26', 'Q27', 'Q30', 'Q31', 'Q33'],
    'Employer_Contribution': ['PC', 'POS'],
    'OE': ['Q7', 'Q20', 'Q28', 'Q29'],
    'CAP': ['Q1', 'Q14'],
    'JE': ['Q2', 'Q3', 'Q6'],
    'Employee_Contribution': ['OE', 'CAP', 'JE'],
    'Satisfaction': ['Q34'],
    'CP_S': ['Q15', 'Q17', 'Q18'],
    'CP_P': ['Q16'],
    'CP': ['CP_S', 'CP_P'],
    'JP': ['Q4'],
    'WT': ['Q40', 'Q41', 'Q42', 'Q43'],
    'Hybrid_working': ['Q22', 'Q23', 'Q24']
}

# Calculate mean values for each variable and add to the list of dictionaries
for variable, questions in variables.items():
    # Check if the variable is grouped
    if variable in ['Employer_Contribution','Employee_Contribution','CP']:
        # Extract the column names from the variables
        question_columns = [variables[question] for question in questions]
        # Flatten the list of column names
        question_columns = [item for sublist in question_columns for item in sublist]
        # Calculate the mean for the grouped columns
        mean_value = df[question_columns].mean(axis=1).mean()
    else:
        # Calculate the mean for the single group of columns
        mean_value = df[questions].mean(axis=1).mean()
    
    # Append the mean value to the DataFrame
    mean_data.append({'Question': variable, 'Mean Value': mean_value})

# Convert the list of dictionaries into a DataFrame
mean_df = pd.DataFrame(mean_data)
df['PC'] = df[['Q5', 'Q13', 'Q19', 'Q32']].mean(axis=1)
df['POS'] = df[['Q25', 'Q26', 'Q27', 'Q30', 'Q31', 'Q33']].mean(axis=1)
df['Employer Contribution']=df[['PC','POS']].mean(axis=1)
df['OE'] = df[['Q7', 'Q20', 'Q28', 'Q29']].mean(axis=1)
df['CAP'] = df[['Q1', 'Q14']].mean(axis=1)
df['JE'] = df[['Q2', 'Q3', 'Q6']].mean(axis=1)
df['Employee_Contribution'] = df[['OE', 'CAP', 'JE']].mean(axis=1)
df['Satisfaction'] = df[['Q34']].mean(axis=1)
df['CP_S'] = df[['Q15', 'Q17', 'Q18']].mean(axis=1)
df['CP_P'] = df[['Q16']].mean(axis=1)
df['CP'] = df[['CP_S', 'CP_P']].mean(axis=1)
df['JP'] = df[['Q4']].mean(axis=1)
df['WT'] = df[['Q40', 'Q41', 'Q42', 'Q43']].mean(axis=1)
df['Hybrid_working'] = df[['Q22', 'Q23', 'Q24']].mean(axis=1)

# Define the list of predictor questions
predictor_questions = [
    'Q16', 'Q15', 'Q17', 'Q18', 'Q4', 'Q5', 'Q13',
    'Q19', 'Q32', 'Q25', 'Q26', 'Q27', 'Q30', 'Q31', 'Q33', 'Q34', 'Q40',
    'Q41', 'Q42', 'Q43'
]

# Define the target variable
target_variable = 'Employee_Contribution'

# Prepare the data
X = df[predictor_questions]
y = df[target_variable]

# Fit the linear regression model
model = sm.OLS(y, sm.add_constant(X)).fit()

# Extract p-values and coefficients
p_values = model.pvalues[1:]  # Exclude the intercept
coefficients = model.params[1:]  # Exclude the intercept

# Create a DataFrame to store the results
results_df = pd.DataFrame({
    'Key drivers of Employee Contribution': [question_labels[predictor] for predictor in X.columns],
    'Impact': coefficients.values * 25,  # Multiply coefficient values by 25
    'P-value': ["{:.2f}".format(p_value) for p_value in p_values.values],  # Format p-values to two decimal points
})

# Remove rows with p-values above 0.05 and sort by Impact
results_df = results_df[results_df['P-value'].astype(float) < 0.05]
results_df = results_df.reindex(results_df['Impact'].abs().sort_values(ascending=False).index)

# Print the results
print("Key drivers of Employee Contribution", "Impact", "P-value", sep="\t")
for index, row in results_df.iterrows():
    print(f"{row['Key drivers of Employee Contribution']:<100} {row['Impact']:.2f} {row['P-value']:<10}")


# In[ ]:




